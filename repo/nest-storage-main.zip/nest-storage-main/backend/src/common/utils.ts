import { ulid } from 'ulid';

export const makeUlid = () => ulid();

export const serializeData = () => {};
export const unserializeData = () => {};
