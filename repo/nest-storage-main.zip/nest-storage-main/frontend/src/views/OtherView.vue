<template>
  <main>
    <h1>This other page</h1>
  </main>
</template>
