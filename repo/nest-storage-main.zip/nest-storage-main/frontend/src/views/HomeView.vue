<script setup lang="ts">
import TreeContainer from '../components/tree/TreeContainer.vue'
</script>

<template>
  <main>
    <TreeContainer />
  </main>
</template>
