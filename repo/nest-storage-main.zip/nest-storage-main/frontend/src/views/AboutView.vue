<template>
  <main>
    <div class="about">
    <h1>This is an about page</h1>
  </div>
  </main>
</template>

<style>
</style>
